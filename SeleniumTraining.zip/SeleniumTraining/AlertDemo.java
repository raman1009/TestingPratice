import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.NoAlertPresentException;	
import org.openqa.selenium.Alert;

public class AlertDemo {

	public static void main(String[] args) throws NoAlertPresentException,InterruptedException  {									
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\tgupta\\Downloads\\chromedriver_win32(1)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		//open the URL
		driver.get("http://demo.guru99.com/test/delete_customer.php");			

		//Enter the ID
		driver.findElement(By.name("cusid")).sendKeys("53920");	
		
		//CLick the Submit
		driver.findElement(By.name("submit")).submit();			

		//After clicking Submit, it will give a popup Selenium can not locate these popups so we need to switch to that alert
		Alert alert = driver.switchTo().alert();		

		//Now once we switched to alert, we can get the text of that alert    
		String alertMessage= driver.switchTo().alert().getText();		

		// Displaying alert message		
		System.out.println(alertMessage);	
		Thread.sleep(5000);

		//accept method is used to click ok on that alert	
		alert.accept();	
		
		//dismiss method is used to click cancel on the alert
		alert.dismiss();
		
		driver.close();
	}	

}