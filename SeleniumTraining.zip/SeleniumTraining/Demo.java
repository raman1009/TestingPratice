 import java.awt.AWTException;
import java.awt.Desktop.Action;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Demo {

	private static WebDriver driver;
	public static void main(String[] args) throws InterruptedException, AWTException {

		//Set the property of Chrome driver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\tgupta\\Downloads\\chromedriver_win32(1)\\chromedriver.exe");

		//Create the object of ChromeDriver class, it will open the chrome browser 
		driver = new ChromeDriver();

		//implicit wait for 10 secs. (Implicit wait will wait for every element for 10 secs.)
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Open the URL, (we can use driver.get("http://newtours.demoaut.com") also for opening the URL)
		driver.navigate().to("http://newtours.demoaut.com");

		//driver.get("http://newtours.demoaut.com");

		WebElement userName = driver.findElement(By.xpath("//input[@name='userName']"));

		//Explicit wait used for particular element. For using Explicit wait create the object of WebDriverWait class 
		WebDriverWait wait = new WebDriverWait(driver,10); 

		//using the wait, call the until function(here we are waiting for username element for 10 seconds)
		wait.until(ExpectedConditions.visibilityOf(userName));

		//Check whether user name field is present or not on the screen, if present then enter the username
		boolean isUserNameDisplyed = driver.findElement(By.xpath("//input[@name='userName']")).isDisplayed();
		if(isUserNameDisplyed){
			userName.click();
			userName.sendKeys("readonly");
		}

		//check whether password field is present or not on the screen, if present then enter the password
		boolean isPassDisplyed = driver.findElement(By.xpath("//input[@name='password']")).isDisplayed();
		if(isPassDisplyed){
			driver.findElement(By.xpath("//input[@name='password']")).click();
			driver.findElement(By.xpath("//input[@name='password']")).sendKeys("readonly");
		}

		//Click on Sign In button
		driver.findElement(By.xpath("//input[@name='login']")).click();

		//For sign in, instead of clicking the sign in button you can send Enter command also using Robot class
		/*Robot rob = new Robot();
		rob.keyPress(KeyEvent.VK_ENTER);*/

		//For getting the URL which is currently opened in browser
		//String url = driver.getCurrentUrl();

		//It will store all the web elements in the List and with the help of foreach loop or normal for loop you can can access those elements
		List<WebElement> list =  driver.findElements(By.xpath("//tr[@class='mouseOut']"));
		int size = list.size();

		System.out.println("size "+size);

		//Instead of using Robot class we can use Action class also for sending the Keyboard command 
		Actions act = new Actions(driver);
		
		//Using for each loop to access all the elements one by one in the List
		for(WebElement wEle:list){
			Thread.sleep(5000);
			act.moveToElement(wEle).build().perform();	
			System.out.println("click");
		}

		//Generating the Random number using Random class
		Random rd=new Random();
		int a =rd.nextInt(4);

		//For selecting the dropdown, need to create the object of Select class.
		Select sl = new Select(driver.findElement(By.xpath("//select[@name='passCount']")));

		//Converting the integar random number in to the string 
		String ddvalue = Integer.toString(a);

		//Select class has various methods to select the values in dropdown, here we used selectByVisibleText method.
		sl.selectByVisibleText(ddvalue);

		//Closes the current window
		driver.close();

		//Closes all the windows opened with that driver
		driver.quit();

		//It terminates the whole execution
		System.exit(0);
	}
}
